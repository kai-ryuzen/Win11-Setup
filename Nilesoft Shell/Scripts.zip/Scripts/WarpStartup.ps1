Remove-Item "C:\Scripts\State\Warp.connected" -Force -ErrorAction SilentlyContinue
