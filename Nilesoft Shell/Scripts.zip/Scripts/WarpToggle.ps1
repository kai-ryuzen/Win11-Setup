﻿# ==========================================
# Cloudflare WARP Toggle v3
# ==========================================

# ---------- Configuration ----------

$ServiceName = "CloudflareWARP"
$StateFile   = "C:\Scripts\State\Warp.connected"

$StateFolder = Split-Path $StateFile

if (-not (Test-Path $StateFolder)) {
    New-Item -ItemType Directory -Path $StateFolder -Force | Out-Null
}

# ---------- Helper Functions ----------

function Wait-ServiceState {

    param(
        [string]$Name,
        [string]$DesiredState,
        [int]$Timeout = 10
    )

    $service = Get-Service -Name $Name
    $end = (Get-Date).AddSeconds($Timeout)

    while ((Get-Date) -lt $end) {

        $service.Refresh()

        if ($service.Status.ToString() -eq $DesiredState) {
            return $true
        }

        Start-Sleep -Milliseconds 250
    }

    return $false
}

# ---------- Self Elevate ----------

$currentUser = New-Object Security.Principal.WindowsPrincipal(
    [Security.Principal.WindowsIdentity]::GetCurrent()
)

if (-not $currentUser.IsInRole(
    [Security.Principal.WindowsBuiltInRole]::Administrator))
{
    $arguments = "-ExecutionPolicy Bypass -File `"$PSCommandPath`""

    if ($MyInvocation.UnboundArguments.Count -gt 0) {
        $arguments += " " + ($MyInvocation.UnboundArguments -join " ")
    }

    Start-Process powershell.exe `
        -Verb RunAs `
        -ArgumentList $arguments

    exit
}

function Get-WarpState {

    $status = warp-cli status 2>&1

    if ($status -match "Status update: Connected") {
        return "Connected"
    }

    if ($status -match "Status update: Disconnected") {
        return "Disconnected"
    }

    if ($status -match "Unable to connect") {
        return "Stopped"
    }

    return "Unknown"
}

# ---------- Connect ----------

function Connect-Warp {

    Write-Host ""
    Write-Host "Starting service..."

    Start-Service $ServiceName -ErrorAction Stop

    if (-not (Wait-ServiceState $ServiceName "Running")) {
        throw "Service failed to start."
    }

    Write-Host "Waiting for daemon..."

    do {

        Start-Sleep -Milliseconds 500
        $state = Get-WarpState

    } until ($state -ne "Stopped")

    Write-Host "Connecting..."

    warp-cli connect | Out-Null

    for ($i = 0; $i -lt 20; $i++) {

        Start-Sleep -Milliseconds 500

        $state = Get-WarpState

        if ($state -eq "Connected") {

            New-Item -Path $StateFile -ItemType File -Force | Out-Null

            Write-Host ""
            Write-Host "✓ Connected"

            return
        }
    }

    throw "VPN failed to connect."
}

# ---------- Disconnect ----------

function Disconnect-Warp {

    Write-Host ""
    Write-Host "Disconnecting..."

    warp-cli disconnect | Out-Null

    for ($i = 0; $i -lt 20; $i++) {

        Start-Sleep -Milliseconds 250

        $state = Get-WarpState

        if ($state -eq "Disconnected") {
            break
        }
    }

    Write-Host "Stopping service..."

    Stop-Service $ServiceName -Force -ErrorAction Stop

    if (-not (Wait-ServiceState $ServiceName "Stopped")) {
        throw "Service failed to stop."
    }

    Remove-Item $StateFile -Force -ErrorAction SilentlyContinue

    Write-Host ""
    Write-Host "✓ Disconnected"
}

# ---------- Main ----------

try {

    $state = Get-WarpState

    Write-Host ""
    Write-Host "Current State : $state"
    Write-Host ""

    switch ($state) {

        "Connected" {
            Disconnect-Warp
        }

        "Disconnected" {
            Connect-Warp
        }

        "Stopped" {
            Connect-Warp
        }

        default {
            throw "Unknown WARP state."
        }
    }
}
catch {

    Write-Host ""
    Write-Host "ERROR:"
    Write-Host $_.Exception.Message
}